from pathlib import Path
import hashlib,json,tarfile,struct
repo=Path('/home/xaz/Projects/goo-gsharp');root=Path('/tmp/goo-final-release-review')
out=repo/'docs/perf/evidence/final-release-2026-09-05';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
success=['api','svg','gallery','api-docs','lint-final','shadergen','onboarding','queue','timeline','metrics','pipeline','effect','liquid']
for name in success:assert json.loads((root/(name+'.json')).read_text())['exit_code']==0
captures=[]
for material in ['terminal','liquid']:
 old=root/'gallery-runtime/Shaders'/(material+'_glass.goo-effect')
 current=repo/'apps/Goo.Gallery/bin/Release/net10.0/Shaders'/(material+'_glass.goo-effect')
 assert old.read_bytes()==current.read_bytes()
 for scale,folder in [(1,material),(1.5,material+'-1.5x')]:
  p=root/folder/'capture.png';width,height=struct.unpack('>II',p.read_bytes()[16:24])
  assert (width,height)==(round(1120*scale),round(760*scale))
  assert (root/folder/'runtime.log').read_text()==''
  captures.append(dict(material=material,scale=scale,width=width,height=height,sha256=sha(p),shader_sha256=sha(current)))
files=list(root.glob('*.log'))+list(root.glob('*.json'))+list(root.glob('*.py'))
files += [p for p in (root/'shader-audit').iterdir() if p.is_file() and p.suffix in ['.log','.json','.md','.txt','.spv','.goo-effect']]
for folder in ['terminal','liquid','terminal-1.5x','liquid-1.5x']:
 files += [root/folder/name for name in ['capture.png','runtime.log','capture.log']]
files=sorted(set(files))
records=[dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
archive=out/'verification.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
(out/'files.json').write_text(json.dumps(records,indent=2)+'\n')
summary=dict(scope='Final pre-push review after reconciling origin/main v0.4.2',core_passed=317,api_passed=12,svg_passed=10,gallery_effects=12,canonical_shaders=18,successful_checks=success,native_fragment_backends=['NVIDIA RTX 3080','lavapipe'],expected_negative_controls=['old Lava shader fails clip destination','old CRT shader fails sampled-alpha coverage'],captures=captures,raw_archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),limitations=['Full hosted macOS and package CI required before tagging','Physical Mac UAT deferred','Earlier failed build/lint attempts retained separately from final passing checks'])
(out/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive))))
