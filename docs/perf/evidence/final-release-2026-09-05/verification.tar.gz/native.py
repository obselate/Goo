import os,subprocess
r='/tmp/goo-final-release-review/run.py'
env=os.environ.copy()
env.update(PATH='/tmp/goo-weston-runtime/usr/bin:'+env['PATH'],LD_LIBRARY_PATH='/tmp/goo-weston-runtime/usr/lib:/tmp/goo-weston-runtime/usr/lib/weston',WESTON_MODULE_MAP='headless-backend.so=/tmp/goo-weston-runtime/usr/lib/libweston-15/headless-backend.so',XDG_CONFIG_HOME='/tmp/goo-release-0.5.0/weston-config',SDL_VIDEODRIVER='wayland',LIBGL_ALWAYS_SOFTWARE='1',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_DRIVER_FILES='/usr/share/vulkan/icd.d/lvp_icd.json',GOO_VK_DIAGNOSTICS='1')
for name,flag in [('queue','GOO_QUEUE_WAKE_SMOKE'),('timeline','GOO_TIMELINE_COMPLETION_SMOKE'),('metrics','GOO_PRIMITIVE_METRICS_SMOKE'),('pipeline','GOO_PIPELINE_IDENTITY_SMOKE'),('effect','GOO_SHADER_EFFECT_SMOKE'),('liquid','GOO_LIQUID_GLASS_ALPHA_SMOKE')]:
 subprocess.run(['python3',r,name,'.github/scripts/with-headless-wayland.sh','env',flag+'=1','dotnet','tests/Goo.AsyncReadbackSmoke/bin/Release/net10.0/Goo.AsyncReadbackSmoke.dll'],env=env,check=True)
