import hashlib,os,subprocess
from pathlib import Path
repo=Path('/home/xaz/Projects/goo-gsharp')
r='/tmp/goo-final-release-review/run.py'
env={**os.environ,'SLANG_SDK':'/tmp/goo-slang-2026.16','VULKAN_SDK':'/tmp/goo-ci-slang-vYVFSV'}
def run(name,cmd):subprocess.run(['python3',r,name,*cmd],env=env,check=True)
run('api',['dotnet','test','tests/Goo.ApiContractTests/Goo.ApiContractTests.csproj','-c','Release','-p:TreatWarningsAsErrors=true','--nologo'])
run('svg',['dotnet','test','tests/Goo.Svg.Tests/Goo.Svg.Tests.csproj','-c','Release','-p:TreatWarningsAsErrors=true','--nologo'])
run('gallery',['dotnet','build','apps/Goo.Gallery/Goo.Gallery.gsproj','-c','Release','-p:TreatWarningsAsErrors=true','--nologo'])
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'docs/api').glob('*.md')}
run('api-docs',['dotnet','tools/Goo.ApiDocs/bin/Release/net10.0/Goo.ApiDocs.dll'])
after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'docs/api').glob('*.md')}
assert before==after,'API docs changed on regeneration'
run('lint',['dotnet','tools/Goo.Gslint/bin/Release/net10.0/Goo.Gslint.dll','--strict','--severity','GL0005=none','--severity','GL0006=none','.'])
run('shadergen',['dotnet','tools/Goo.ShaderGen/bin/Release/net10.0/Goo.ShaderGen.dll','check'])
run('onboarding',['python3','.github/scripts/validate-onboarding.py'])
print('Final API, SVG, Gallery, documentation, lint, shader and metadata verification passed')
