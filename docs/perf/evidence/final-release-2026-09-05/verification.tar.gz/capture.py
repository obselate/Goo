from pathlib import Path
import json, os, subprocess, time
root=Path('/tmp/goo-final-release-review')
repo=Path('/home/xaz/Projects/goo-gsharp')
for material in ['terminal','liquid']:
 folder=root/material
 folder.mkdir(exist_ok=True)
 env={**os.environ,'WAYLAND_DISPLAY':'goo-final-review','GOO_DEVTOOLS':'1','GOO_DEVTOOLS_DIR':str(folder),'GOO_GLASS_LAB':'1','GOO_GLASS_MATERIAL':material}
 with (folder/'runtime.log').open('w') as log:
  proc=subprocess.Popen(['dotnet',str(root/'gallery-runtime/Goo.Gallery.dll')],cwd=repo,env=env,stdout=log,stderr=log)
  try:
   deadline=time.monotonic()+25
   while time.monotonic()<deadline:
    if proc.poll() is not None: raise RuntimeError((folder/'runtime.log').read_text())
    if list(folder.glob('*.json')):break
    time.sleep(.1)
   time.sleep(1)
   result=subprocess.run(['dotnet',str(repo/'tools/Goo.DevTools.Cli/bin/Release/net10.0/Goo.DevTools.Cli.dll'),'capture','--pid',str(proc.pid),'--output',str(folder/'capture.png')],cwd=repo,env=env,capture_output=True,text=True,timeout=20)
   (folder/'capture.log').write_text(result.stdout+result.stderr)
   print(material,result.returncode,result.stdout,result.stderr,flush=True)
   result.check_returncode()
  finally:
   proc.terminate()
   proc.wait(timeout=5)
