from pathlib import Path
import os,subprocess,hashlib,json
r=Path('/home/xaz/Projects/goo-gsharp');o=Path('/tmp/goo-release-0.5.0')
s=(o/'native-ci.py').read_text().split('for name,flag,app in ')[0]
scope={};exec(s,scope);env=scope['env']
p=r/'tests/Goo.VulkanProof/bin/Release/net10.0/Generated/Shaders/analytic_sampled_image.frag.spv'
fixed=p.read_bytes();old=subprocess.check_output(['git','show','HEAD:tests/Goo.VulkanProof/Generated/Shaders/analytic_sampled_image.frag.spv'],cwd=r)
try:
 p.write_bytes(old)
 result=subprocess.run(['python3',str(o/'run.py'),'ci-image-old-shader','.github/scripts/with-headless-wayland.sh','env','GOO_VK_IMAGE_READBACK=1','dotnet','tests/Goo.VulkanProof/bin/Release/net10.0/Goo.VulkanProof.dll'],cwd=r,env=env)
 assert result.returncode!=0
 assert 'Vulkan sampled image readback pixels are invalid' in (o/'ci-image-old-shader.log').read_text()
finally:p.write_bytes(fixed)
assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(fixed).digest()
(o/'image-negative-control.json').write_text(json.dumps({'passed':True,'old_shader_sha256':hashlib.sha256(old).hexdigest(),'fixed_shader_sha256':hashlib.sha256(fixed).hexdigest(),'rejected_old_shader':True,'fixed_runtime_restored':True},indent=2)+'\n')
print('Old shader rejected by portable pixel regions, fixed runtime restored')
