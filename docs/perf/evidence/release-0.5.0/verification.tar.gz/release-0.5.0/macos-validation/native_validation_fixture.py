#!/usr/bin/env python3
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import struct


def load_validator(path):
    spec = importlib.util.spec_from_file_location("validate_release", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def dylib_command(kind, name):
    raw = name.encode("utf-8") + b"\0"
    size = (24 + len(raw) + 7) & ~7
    return (
        struct.pack("<IIIIII", kind, size, 24, 0, 0, 0)
        + raw
        + b"\0" * (size - 24 - len(raw))
    )


def macos_version(major, minor=0, patch=0):
    return major << 16 | minor << 8 | patch


def dylib_image(name, dependencies, minimum=macos_version(14)):
    commands = [
        dylib_command(0x0D, name),
        *(dylib_command(0x0C, dependency) for dependency in dependencies),
        struct.pack("<IIIIII", 0x32, 24, 1, minimum, macos_version(15), 0),
    ]
    body = b"".join(commands)
    return (
        struct.pack(
            "<IIIIIIII",
            0xFEEDFACF,
            0x0100000C,
            0,
            6,
            len(commands),
            len(body),
            0,
            0,
        )
        + body
    )


def synthetic_payloads(validator, manifest):
    payloads = {
        "libMoltenVK.dylib": dylib_image(
            "@rpath/libMoltenVK.dylib",
            ["/usr/lib/libSystem.B.dylib"],
            macos_version(12),
        ),
        "libSDL3.dylib": dylib_image(
            "@rpath/libSDL3.dylib",
            ["/usr/lib/libSystem.B.dylib"],
        ),
    }
    for role, name in manifest["outputs"]["osx-arm64"].items():
        payloads[name] = dylib_image(
            manifest["build"]["macos"]["requiredInstallName"][role],
            manifest["build"]["macos"]["requiredNeeded"][role],
        )
    recorded = copy.deepcopy(manifest)
    build_evidence = copy.deepcopy(manifest["build"])
    build_evidence.pop("environments")
    build_evidence.update(
        target="osx-arm64",
        sourceDirectory="temporary",
        environment=manifest["build"]["environments"]["osx-arm64"],
        toolchain={},
        deploymentTarget="14.0",
    )
    recorded["buildEvidence"] = build_evidence
    recorded["artifacts"] = {}
    for role, name in manifest["outputs"]["osx-arm64"].items():
        data = payloads[name]
        metadata = validator.macho_metadata(data)
        recorded["artifacts"][role] = {
            "file": name,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "architectures": ["arm64"],
            "installName": metadata["installName"],
            "needed": metadata["dependencies"],
            "exports": manifest["requiredExports"][role],
        }
    payloads["text-native-build.json"] = json.dumps(
        recorded, sort_keys=True
    ).encode("utf-8")
    return payloads


def expect_rejection(label, function, expected):
    try:
        function()
    except SystemExit as error:
        message = str(error)
        if expected not in message:
            raise RuntimeError(
                f"{label}: expected {expected!r}, received {message!r}"
            ) from error
        print(f"PASS {label}: {message}")
        return
    raise RuntimeError(f"{label}: unexpectedly accepted")


def replace_text_record(payloads, update):
    changed = dict(payloads)
    record = json.loads(changed["text-native-build.json"])
    update(record)
    changed["text-native-build.json"] = json.dumps(
        record, sort_keys=True
    ).encode("utf-8")
    return changed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--repo",
        type=Path,
        default=Path("/home/xaz/Projects/goo-gsharp"),
    )
    parser.add_argument(
        "--stale-native-root",
        type=Path,
        default=Path("/tmp/goo-macos-candidate.Hoxkeg/native"),
    )
    args = parser.parse_args()
    validator_path = args.repo / ".github/scripts/validate-release.py"
    manifest_path = args.repo / "tools/Goo.TextNative/manifest.json"
    validator = load_validator(validator_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    print(f"validator_sha256={hashlib.sha256(validator_path.read_bytes()).hexdigest()}")
    print(f"manifest_sha256={hashlib.sha256(manifest_path.read_bytes()).hexdigest()}")

    stale = {
        path.name: path.read_bytes()
        for path in args.stale_native_root.iterdir()
        if path.is_file()
    }
    for name in sorted(stale):
        print(f"stale_sha256 {hashlib.sha256(stale[name]).hexdigest()} {name}")
    molten = validator.macho_metadata(stale["libMoltenVK.dylib"])
    sdl = validator.macho_metadata(stale["libSDL3.dylib"])
    if molten["minimumMacOS"] != (12, 0, 0):
        raise RuntimeError("stale MoltenVK minimum changed")
    if sdl["minimumMacOS"] != (15, 0, 0):
        raise RuntimeError("stale SDL minimum changed")
    expect_rejection(
        "stale-candidate-minos",
        lambda: validator.validate_macos_payloads(stale),
        "libSDL3.dylib requires macOS 15.0.0",
    )

    valid = synthetic_payloads(validator, manifest)
    validator.validate_macos_payloads(valid)
    print("PASS synthetic-current-policy")

    patch_level = dict(valid)
    patch_level["libSDL3.dylib"] = dylib_image(
        "@rpath/libSDL3.dylib",
        ["/usr/lib/libSystem.B.dylib"],
        macos_version(14, 0, 1),
    )
    expect_rejection(
        "minimum-14.0.1",
        lambda: validator.validate_macos_payloads(patch_level),
        "requires macOS 14.0.1",
    )

    wrong_arch = dict(valid)
    data = wrong_arch["libSDL3.dylib"]
    wrong_arch["libSDL3.dylib"] = (
        data[:4] + struct.pack("<I", 0x01000007) + data[8:]
    )
    expect_rejection(
        "wrong-architecture",
        lambda: validator.validate_macos_payloads(wrong_arch),
        "not a thin arm64 Mach-O dylib",
    )
    truncated = dict(valid)
    truncated["libSDL3.dylib"] = b"bad"
    expect_rejection(
        "truncated-image",
        lambda: validator.validate_macos_payloads(truncated),
        "truncated Mach-O header",
    )

    stale_provenance = replace_text_record(
        valid,
        lambda record: record["build"]["macos"]["requiredNeeded"]["harfbuzz"].remove(
            "/usr/lib/libc++.1.dylib"
        ),
    )
    expect_rejection(
        "stale-text-policy",
        lambda: validator.validate_macos_payloads(stale_provenance),
        "text-native provenance is stale: build",
    )

    dependency_drift = dict(valid)
    role = "harfbuzz"
    name = manifest["outputs"]["osx-arm64"][role]
    dependency_drift[name] = dylib_image(
        manifest["build"]["macos"]["requiredInstallName"][role],
        manifest["build"]["macos"]["requiredNeeded"][role]
        + ["/usr/lib/libobjc.A.dylib"],
    )
    metadata = validator.macho_metadata(dependency_drift[name])
    def update_dependency_record(record):
        artifact = record["artifacts"][role]
        artifact["bytes"] = len(dependency_drift[name])
        artifact["sha256"] = hashlib.sha256(dependency_drift[name]).hexdigest()
        artifact["needed"] = metadata["dependencies"]
    dependency_drift = replace_text_record(
        dependency_drift, update_dependency_record
    )
    expect_rejection(
        "text-dependency-drift",
        lambda: validator.validate_macos_payloads(dependency_drift),
        "artifact provenance is invalid",
    )
    print("RESULT all fixtures passed")


if __name__ == "__main__":
    main()
