import os,subprocess,sys
from pathlib import Path
env=os.environ.copy()
env.update(PATH='/tmp/goo-weston-runtime/usr/bin:'+env['PATH'],LD_LIBRARY_PATH='/tmp/goo-weston-runtime/usr/lib:/tmp/goo-weston-runtime/usr/lib/weston',WESTON_MODULE_MAP='headless-backend.so=/tmp/goo-weston-runtime/usr/lib/libweston-15/headless-backend.so',XDG_CONFIG_HOME='/tmp/goo-release-0.5.0/weston-config',SDL_VIDEODRIVER='wayland',LIBGL_ALWAYS_SOFTWARE='1',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_DRIVER_FILES='/usr/share/vulkan/icd.d/lvp_icd.json',GOO_VK_DIAGNOSTICS='1')
for name,flag,app in [('ci-image','GOO_VK_IMAGE_READBACK','Goo.VulkanProof'),('ci-liquid','GOO_LIQUID_GLASS_ALPHA_SMOKE','Goo.AsyncReadbackSmoke'),('ci-effect','GOO_SHADER_EFFECT_SMOKE','Goo.AsyncReadbackSmoke')]:
 command=['python3','/tmp/goo-release-0.5.0/run.py',name,'.github/scripts/with-headless-wayland.sh','env',flag+'=1','dotnet',f'tests/{app}/bin/Release/net10.0/{app}.dll']
 subprocess.run(command,env=env,check=True)
