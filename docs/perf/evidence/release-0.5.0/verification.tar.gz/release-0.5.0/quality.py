import os,subprocess
r='/tmp/goo-release-0.5.0/run.py'
env=os.environ.copy()
env.update(SLANG_SDK='/tmp/goo-slang-2026.16',VULKAN_SDK='/tmp/goo-ci-slang-vYVFSV')
for name,cmd in [
 ('onboarding',['python3','.github/scripts/validate-onboarding.py']),
 ('api',['dotnet','test','tests/Goo.ApiContractTests/Goo.ApiContractTests.csproj','-c','Release','-p:TreatWarningsAsErrors=true','--nologo']),
 ('core',['dotnet','test','tests/Goo.CoreBehaviorTests/Goo.CoreBehaviorTests.csproj','-c','Release','-p:TreatWarningsAsErrors=true','--nologo']),
 ('svg',['dotnet','test','tests/Goo.Svg.Tests/Goo.Svg.Tests.csproj','-c','Release','-p:TreatWarningsAsErrors=true','--nologo'])]:
 subprocess.run(['python3',r,name,*cmd],env=env,check=True)
