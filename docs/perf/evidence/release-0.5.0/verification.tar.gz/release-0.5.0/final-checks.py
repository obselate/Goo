import hashlib,os,subprocess
from pathlib import Path
repo=Path('/home/xaz/Projects/goo-gsharp');r='/tmp/goo-release-0.5.0/run.py'
env=os.environ.copy();env.update(SLANG_SDK='/tmp/goo-slang-2026.16',VULKAN_SDK='/tmp/goo-ci-slang-vYVFSV')
def run(name,cmd):subprocess.run(['python3',r,name,*cmd],env=env,check=True)
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'docs/api').glob('*.md')}
run('api-docs',['dotnet','tools/Goo.ApiDocs/bin/Release/net10.0/Goo.ApiDocs.dll'])
after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'docs/api').glob('*.md')}
assert before==after,'API docs changed on regeneration'
run('strict-lint',['dotnet','tools/Goo.Gslint/bin/Release/net10.0/Goo.Gslint.dll','--strict','--severity','GL0005=none','--severity','GL0006=none','.'])
run('shadergen-check',['dotnet','tools/Goo.ShaderGen/bin/Release/net10.0/Goo.ShaderGen.dll','check'])
run('vulnerabilities',['dotnet','list','Goo/Goo.gsproj','package','--vulnerable','--include-transitive','--format','json'])
assert '"severity"' not in Path('/tmp/goo-release-0.5.0/vulnerabilities.log').read_text(),'Known vulnerable package reported'
print('API docs unchanged, strict lint, ShaderGen and vulnerability gate passed')
