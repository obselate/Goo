import os,subprocess
r='/tmp/goo-release-0.5.0/run.py'
env=os.environ.copy();env.update(SLANG_SDK='/tmp/goo-slang-2026.16',VULKAN_SDK='/tmp/goo-ci-slang-vYVFSV')
for name,project in [('image-build','tests/Goo.VulkanProof/Goo.VulkanProof.gsproj'),('async-build','tests/Goo.AsyncReadbackSmoke/Goo.AsyncReadbackSmoke.gsproj')]:
 subprocess.run(['python3',r,name,'dotnet','build',project,'-c','Release','-p:TreatWarningsAsErrors=true','--nologo'],env=env,check=True)
subprocess.run(['python3','/tmp/goo-release-0.5.0/native-ci.py'],check=True)
