#!/usr/bin/env bash
set -euo pipefail
out=/tmp/goo-nonuat-2026-09-05/gpu/layers-off/results-v2
control=/tmp/goo-nonuat-2026-09-05/gpu/path-candidate/runtime-ab/control
candidate=/tmp/goo-nonuat-2026-09-05/gpu/path-candidate/runtime-ab/candidate
glass_runtime=/tmp/goo-nonuat-2026-09-05/gpu/runtime/final-correctness
glass_shaders=/tmp/goo-nonuat-2026-09-05/gpu/shaders/final-correctness
if [[ -e "$out" ]]; then
  printf 'refusing existing output directory: %s\n' "$out" >&2
  exit 3
fi
mkdir -p "$out/layer-proof" "$out/hardware" "$out/path" "$out/glass"
run_layers_off() {
  env -u VK_INSTANCE_LAYERS \
    -u VK_LOADER_LAYERS_ENABLE \
    -u VK_LOADER_LAYERS_ALLOW \
    -u VK_LAYER_PATH \
    -u VK_ADD_LAYER_PATH \
    -u VK_LOADER_DEBUG \
    -u MANGOHUD \
    -u ENABLE_VKBASALT \
    -u ENABLE_LAYER_MESA_ANTI_LAG \
    -u __NV_PRIME_RENDER_OFFLOAD \
    -u NVPRESENT_ENABLE_SMOOTH_MOTION \
    VK_LOADER_LAYERS_DISABLE='~implicit~' \
    DISABLE_MANGOHUD=1 \
    DISABLE_VKBASALT=1 \
    DISABLE_LAYER_MESA_ANTI_LAG=1 \
    NODEVICE_SELECT=1 \
    DISABLE_LAYER_NV_OPTIMUS_1=1 \
    DISABLE_LAYER_NV_PRESENT_1=1 \
    "$@"
}
assert_hash() {
  local expected=$1
  local file=$2
  local actual
  actual=$(sha256sum "$file" | cut -d' ' -f1)
  if [[ "$actual" != "$expected" ]]; then
    printf 'hash mismatch: %s expected=%s actual=%s\n' "$file" "$expected" "$actual" >&2
    exit 4
  fi
}
assert_hash 127ed8a5ff2bc53b65f51c609578a981c6542d76e1ff84ddd36b05aff5a0e3e8 "$control/Goo.AsyncReadbackSmoke.dll"
assert_hash 127ed8a5ff2bc53b65f51c609578a981c6542d76e1ff84ddd36b05aff5a0e3e8 "$candidate/Goo.AsyncReadbackSmoke.dll"
assert_hash a5782bc002bfb584d0512cfe099626fca6bba0339600fc75baeed5d8412b70d9 "$control/Goo.dll"
assert_hash a5782bc002bfb584d0512cfe099626fca6bba0339600fc75baeed5d8412b70d9 "$candidate/Goo.dll"
assert_hash ff8ba0f3b071f3d3f62c8b0ee0fb596558f493f4a23e3139d7c1b71a305d4c2c "$control/Vulkan/Shaders/path_band.frag.spv"
assert_hash d35f24052632ec03b9436cb64963d6cd6b6707a4da1a8f3309d45ca35d5ad03f "$candidate/Vulkan/Shaders/path_band.frag.spv"
assert_hash f3d6946d46cbb78a9c8c4e098369a0fa4ab69f18cd9f157271578f7898b4208f "$control/Vulkan/Shaders/clip_mask.frag.spv"
assert_hash 44d9055153c9bba0822b0eec624473a2468ba30835e6c8d7ec81ed90f3ba8c08 "$candidate/Vulkan/Shaders/clip_mask.frag.spv"
assert_hash 03b910c31e733ba17990d7f77a4c3400f6fcac9eea3a2b65d8baa0650f132fc7 "$glass_shaders/liquid_glass.goo-effect"
assert_hash f25adebefb6563663fec681f4027e40a395bdced41ece691b6d4b8a8a8614758 "$glass_shaders/terminal_glass.goo-effect"
printf '%s\n' \
  'VK_INSTANCE_LAYERS=absent' \
  'VK_LOADER_LAYERS_ENABLE=absent' \
  'VK_LOADER_LAYERS_ALLOW=absent' \
  'VK_LOADER_LAYERS_DISABLE=~implicit~' \
  'MANGOHUD=absent DISABLE_MANGOHUD=1' \
  'ENABLE_VKBASALT=absent DISABLE_VKBASALT=1' \
  'ENABLE_LAYER_MESA_ANTI_LAG=absent DISABLE_LAYER_MESA_ANTI_LAG=1' \
  '__NV_PRIME_RENDER_OFFLOAD=absent DISABLE_LAYER_NV_OPTIMUS_1=1' \
  'NVPRESENT_ENABLE_SMOOTH_MOTION=absent DISABLE_LAYER_NV_PRESENT_1=1' \
  > "$out/layer-environment.txt"
nvidia-smi --query-gpu=name,uuid,driver_version,pstate,clocks.current.graphics,clocks.current.memory,temperature.gpu,power.draw --format=csv > "$out/hardware/nvidia-smi-before.csv"
lscpu > "$out/hardware/lscpu.txt"
uname -a > "$out/hardware/uname.txt"
run_layers_off env VK_LOADER_DEBUG=layer \
  WAYLAND_DISPLAY=goo-nonuat \
  GOO_VK_DIAGNOSTICS=1 \
  GOO_GPU_PATH_BENCHMARK=1 \
  GOO_GPU_FRAGMENT_WIDTH=256 \
  GOO_GPU_FRAGMENT_HEIGHT=256 \
  GOO_GPU_PATH_CONTOURS=1 \
  GOO_GPU_FRAGMENT_WARMUP=0 \
  GOO_GPU_FRAGMENT_SAMPLES=1 \
  GOO_GPU_FRAGMENT_ARTIFACT=layers-off-proof \
  GOO_GPU_FRAGMENT_CAPTURE="$out/layer-proof/proof.ppm" \
  GOO_GPU_FRAGMENT_RAW="$out/layer-proof/proof.csv" \
  timeout 60s dotnet "$candidate/Goo.AsyncReadbackSmoke.dll" \
  > "$out/layer-proof/proof.log" 2>&1
run_path() {
  local lane=$1
  local width=$2
  local height=$3
  local contours=$4
  local rep=$5
  local runtime
  local directory="$out/path/${width}x${height}/c${contours}/${lane}"
  local capture=
  if [[ "$lane" == control ]]; then runtime=$control; else runtime=$candidate; fi
  mkdir -p "$directory"
  if [[ "$rep" == 1 ]]; then capture="$directory/rep1.ppm"; fi
  run_layers_off env \
    WAYLAND_DISPLAY=goo-nonuat \
    GOO_VK_DIAGNOSTICS=1 \
    GOO_GPU_PATH_BENCHMARK=1 \
    GOO_GPU_FRAGMENT_WIDTH="$width" \
    GOO_GPU_FRAGMENT_HEIGHT="$height" \
    GOO_GPU_PATH_CONTOURS="$contours" \
    GOO_GPU_FRAGMENT_WARMUP=300 \
    GOO_GPU_FRAGMENT_SAMPLES=1000 \
    GOO_GPU_FRAGMENT_ARTIFACT="layers-off-${lane}-path-${width}x${height}-c${contours}-r${rep}" \
    GOO_GPU_FRAGMENT_CAPTURE="$capture" \
    GOO_GPU_FRAGMENT_RAW="$directory/rep${rep}.csv" \
    timeout 240s dotnet "$runtime/Goo.AsyncReadbackSmoke.dll" \
    > "$directory/rep${rep}.log" 2>&1
}
for contours in 1 31 33 65; do
  for rep in 1 2 3; do
    if [[ "$rep" == 2 ]]; then
      run_path candidate 256 256 "$contours" "$rep"
      run_path control 256 256 "$contours" "$rep"
    else
      run_path control 256 256 "$contours" "$rep"
      run_path candidate 256 256 "$contours" "$rep"
    fi
  done
done
for spec in 256:256:17 512:512:1 512:512:31 512:512:33 1024:1024:1 1024:1024:31 1024:1024:33; do
  IFS=: read -r width height contours <<< "$spec"
  for rep in 1 2 3; do
    run_path candidate "$width" "$height" "$contours" "$rep"
  done
done
run_glass() {
  local material=$1
  local width=$2
  local height=$3
  local rep=$4
  local directory="$out/glass/${material}/${width}x${height}"
  local capture=
  mkdir -p "$directory"
  if [[ "$rep" == 1 ]]; then capture="$directory/rep1.ppm"; fi
  run_layers_off env \
    WAYLAND_DISPLAY=goo-nonuat \
    GOO_VK_DIAGNOSTICS=1 \
    GOO_GPU_GLASS_BENCHMARK=1 \
    GOO_GPU_GLASS_MATERIAL="$material" \
    GOO_GPU_FRAGMENT_WIDTH="$width" \
    GOO_GPU_FRAGMENT_HEIGHT="$height" \
    GOO_GPU_FRAGMENT_WARMUP=300 \
    GOO_GPU_FRAGMENT_SAMPLES=1000 \
    GOO_GPU_FRAGMENT_SHADER_DIR="$glass_shaders" \
    GOO_GPU_FRAGMENT_ARTIFACT="layers-off-${material}-${width}x${height}-r${rep}" \
    GOO_GPU_FRAGMENT_CAPTURE="$capture" \
    GOO_GPU_FRAGMENT_RAW="$directory/rep${rep}.csv" \
    timeout 240s dotnet "$glass_runtime/Goo.AsyncReadbackSmoke.dll" \
    > "$directory/rep${rep}.log" 2>&1
}
for material in liquid terminal; do
  for spec in 640:480 1120:760 1920:1080; do
    IFS=: read -r width height <<< "$spec"
    for rep in 1 2 3; do
      run_glass "$material" "$width" "$height" "$rep"
    done
  done
done
nvidia-smi --query-gpu=name,uuid,driver_version,pstate,clocks.current.graphics,clocks.current.memory,temperature.gpu,power.draw --format=csv > "$out/hardware/nvidia-smi-after.csv"
find "$out" -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > "$out/SHA256SUMS"
touch "$out/complete"
