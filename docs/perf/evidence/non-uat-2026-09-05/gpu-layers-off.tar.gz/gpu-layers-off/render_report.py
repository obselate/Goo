from pathlib import Path
import json
root=Path('/tmp/goo-nonuat-2026-09-05/gpu/layers-off')
measurements=json.loads((root/'measurements.json').read_text())
decision=json.loads((root/'decision.json').read_text())
provenance=json.loads((root/'provenance.json').read_text())

def ms(value):
    return f'{value / 1_000_000:.3f}'

def ms4(value):
    return f'{value / 1_000_000:.4f}'

lines=[]
lines.extend([
'# Authoritative layers-off GPU fragment measurements, 2026-09-05',
'',
'These results supersede the validation-enabled timing values in `docs/perf/evidence/non-uat-2026-09-05/gpu-validation-enabled`. That archive remains correctness evidence only.',
'',
'Hardware: AMD Ryzen 7 3700X, NVIDIA GeForce RTX 3080, driver 610.57.04, private KWin Wayland compositor `goo-nonuat`, 3840x2160, scale 1. Each result combines three fresh processes with 300 warmup frames and 1,000 measured frames per process. `VK_INSTANCE_LAYERS`, loader enable variables, and implicit-layer enable variables were absent. `VK_LOADER_LAYERS_DISABLE=~implicit~` forced all 10 discovered implicit layers off. The loader proof selected the RTX 3080 and did not activate `VK_LAYER_KHRONOS_validation`.',
'',
'Goo diagnostics, exact completed-frame timestamp matching, visible raster checks, packed-path checks, readback, and cleanup remained enabled. All 63 timing processes resolved every requested timestamp, recorded zero dropped scopes, passed raster/path assertions, and closed cleanly. The raw evidence contains 45,000 path Main samples, 18,000 glass Main samples, and 18,000 glass Effects samples. Values below are combined 3,000-frame P50/P95/P99/worst in milliseconds.',
'',
'## Dense single-band path',
'',
'The fixture uses valid distinct nested rectangle contours with EvenOdd fill. Packed encoder inspection proves actual curve, band, candidate, and fractional-root counts at the sampled pixel. Center, outside, and fractional-edge pixels are validated.',
'',
'| Size | Covered pixels | Contours | Curves | Bands | Candidates | Fractional roots | Overflow | Main P50 | P95 | P99 | Worst |',
'|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|',
])
for row in measurements['path_candidate']:
    main=row['main']
    lines.append(f"| {row['width']}x{row['height']} | {row['covered_pixels']:,} | {row['contours']} | {row['curves']} | {row['bands']} | {row['selected_band_candidates']} | {row['fractional_roots_at_sample']} | {'Yes' if row['overflow'] else 'No'} | {ms(main['p50_ns'])} | {ms(main['p95_ns'])} | {ms(main['p99_ns'])} | {ms(main['worst_ns'])} |")
lines.extend([
'',
'The 65-root case stops at 256x256 because candidate P50 is already above 16.67 ms. No larger 65-root case was run.',
'',
'## Retained overflow fallback',
'',
'The retained shader orders only roots below 0.5 pixel after the 32-root array overflows, then reconstructs distant amount-1 roots from total parity collected in the first pass. The fallback remains quadratic in fractional roots.',
'',
'| Contours | Control P50 ms | Candidate P50 ms | Change | Measured fixture PPM equal |',
'|---:|---:|---:|---:|---:|',
])
for row in decision['comparisons']:
    lines.append(f"| {row['contours']} | {ms4(row['control_p50_ns'])} | {ms4(row['candidate_p50_ns'])} | {row['candidate_change_percent']:+.2f}% | Yes |")
lines.extend([
'',
'The measured no-overflow trade is +2.048 microseconds at 1 root and 0.000 microseconds at 31 roots. The overflow stress gain is 34.96% at 33 roots and 35.64% at 65 roots. Capture equality applies to these measured fixtures only.',
'',
'## Glass',
'',
'The effect covers the stated area over deterministic opaque red and blue stripes with Gallery parameters and a 24-pixel inset. Main includes the nested Effects scope. Do not add Main and Effects.',
'',
'| Material | Window | Covered pixels | Main P50 | P95 | P99 | Worst | Effects P50 | P95 | P99 | Worst |',
'|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|',
])
for row in measurements['glass_final_correctness']:
    main=row['main']
    effects=row['effects']
    lines.append(f"| {row['material'].title()} | {row['width']}x{row['height']} | {row['covered_pixels']:,} | {ms(main['p50_ns'])} | {ms(main['p95_ns'])} | {ms(main['p99_ns'])} | {ms(main['worst_ns'])} | {ms(effects['p50_ns'])} | {ms(effects['p95_ns'])} | {ms(effects['p99_ns'])} | {ms(effects['worst_ns'])} |")
lines.extend([
'',
'At 1920x1080, Effects P50 is 0.185 ms for Liquid and 0.120 ms for Terminal. Both visual shaders remain unchanged apart from the verified liquid alpha correction. Speculative tap reduction is rejected.',
'',
'## Provenance',
'',
])
for key in ('control_app_dll','control_app_pdb','control_goo_dll','control_path_source','control_path_spv','control_clip_spv','control_manifest','candidate_path_source','candidate_path_spv','candidate_clip_spv','candidate_manifest','fixed_liquid_source','fixed_liquid_bundle','terminal_source','terminal_bundle','run_script','loader_proof_log'):
    item=provenance[key]
    lines.append(f"- `{key}`: `{item['sha256']}` ({item['path']})")
lines.extend([
'',
'The control and candidate app DLL, PDB, and Goo DLL are byte-identical. Only path SPIR-V, shared clip-mask SPIR-V, and their manifest differ in the A/B runtime. Root reports the integrated ShaderGen check, vector quality, clip-mask, queue isolation, effect recovery, readback close, liquid alpha, Core 317/317, API 12/12, Release builds, and strict lint all passed before this timing run.',
])
(root/'report.md').write_text('\n'.join(lines)+'\n')
