from pathlib import Path
import hashlib,json,re
root=Path('/tmp/goo-nonuat-2026-09-05/gpu/layers-off')
prov=json.loads((root/'provenance.json').read_text())
actual={}
for name,item in prov.items():
    path=Path(item['path'])
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    if path.stat().st_size != item['size'] or digest != item['sha256']:
        raise RuntimeError(f'provenance mismatch: {name}')
    actual[digest]=str(path)
measurements=json.loads((root/'measurements.json').read_text())
for group in ('path_candidate','path_ab','glass_final_correctness'):
    for row in measurements[group]:
        path=Path(row['directory'])/'rep1.ppm'
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != row['capture_sha256']:
            raise RuntimeError(f'capture hash mismatch: {path}')
        actual[digest]=str(path)
seen={}
for filename in ('report.md','decision.json','measurements.json','provenance.json'):
    text=(root/filename).read_text()
    hashes=set(re.findall(r'(?<![0-9a-f])[0-9a-f]{64}(?![0-9a-f])',text))
    unknown=sorted(hashes-set(actual))
    if unknown:
        raise RuntimeError(f'unverified full hashes in {filename}: {unknown}')
    seen[filename]=len(hashes)
result=root/'results-v2'
logs=list(result.glob('path/**/*.log'))+list(result.glob('glass/**/*.log'))
csvs=list(result.glob('path/**/*.csv'))+list(result.glob('glass/**/*.csv'))
if len(logs)!=63 or len(csvs)!=63:
    raise RuntimeError(f'wrong timing file counts: logs={len(logs)} csvs={len(csvs)}')
verification={
    'authoritative_timing':'layers-off',
    'validation_enabled_timing':'superseded and retained only as correctness evidence',
    'timing_processes':63,
    'path_main_samples':45000,
    'glass_main_samples':18000,
    'glass_effects_samples':18000,
    'raw_checksum_entries':sum(1 for _ in (result/'SHA256SUMS').open()),
    'full_hash_strings_audited':seen,
    'provenance_files_verified':len(prov),
    'loader_proof':'10 implicit layers forced disabled, VK_LAYER_KHRONOS_validation absent, RTX 3080 selected',
    'all_fixture_checks':'exact timestamp resolution, zero dropped scopes, valid raster/path output, strict frame ordering, clean close',
}
(root/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
