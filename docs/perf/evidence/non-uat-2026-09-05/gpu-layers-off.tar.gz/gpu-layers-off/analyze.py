from pathlib import Path
import csv, hashlib, json, math, re
root = Path('/tmp/goo-nonuat-2026-09-05/gpu/layers-off')
final = root / 'results-v2'

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def percentile(values, fraction):
    values = sorted(values)
    return values[max(0, min(len(values) - 1, math.ceil(len(values) * fraction) - 1))]

def parse_log(path):
    lines = [line for line in path.read_text().splitlines() if line.strip()]
    if len(lines) != 1 or not lines[0].startswith('gpu-'):
        raise RuntimeError(f'invalid log {path}: {lines}')
    fields = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        fields[key] = value
    for key in ('gpu_dropped_scope_count', 'raster_valid', 'close'):
        expected = '0' if key == 'gpu_dropped_scope_count' else '1'
        if fields[key] != expected:
            raise RuntimeError(f'{path}: {key}={fields[key]}')
    return fields

def parse_csv(path, effects):
    with path.open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 1000:
        raise RuntimeError(f'{path}: {len(rows)} rows')
    frames = [int(row['frame']) for row in rows]
    main = [int(row['main_ns']) for row in rows]
    fx = [int(row['effects_ns']) for row in rows]
    if any(b <= a for a, b in zip(frames, frames[1:])):
        raise RuntimeError(f'{path}: unordered frames')
    if len(set(frames)) != len(frames) or min(main) <= 0:
        raise RuntimeError(f'{path}: invalid frames or main values')
    if effects and min(fx) <= 0:
        raise RuntimeError(f'{path}: missing effects values')
    if not effects and any(fx):
        raise RuntimeError(f'{path}: unexpected effects values')
    return frames, main, fx

def check_ppm(path, width, height):
    data = path.read_bytes()
    match = re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s', data)
    if not match or int(match.group(1)) != width or int(match.group(2)) != height:
        raise RuntimeError(f'{path}: invalid header')
    if len(data) - match.end() != width * height * 3:
        raise RuntimeError(f'{path}: invalid payload size')
    return hashlib.sha256(data).hexdigest()

def summarize(directory, effects, width, height):
    runs = []
    all_main = []
    all_fx = []
    for rep in range(1, 4):
        log_path = directory / f'rep{rep}.log'
        csv_path = directory / f'rep{rep}.csv'
        fields = parse_log(log_path)
        frames, main, fx = parse_csv(csv_path, effects)
        calculated = {
            'p50_ns': percentile(main, .50),
            'p95_ns': percentile(main, .95),
            'p99_ns': percentile(main, .99),
            'worst_ns': max(main),
        }
        for suffix, value in calculated.items():
            if int(fields[f'gpu_main_{suffix}']) != value:
                raise RuntimeError(f'{log_path}: main {suffix} mismatch')
        if effects:
            fx_calculated = {
                'p50_ns': percentile(fx, .50),
                'p95_ns': percentile(fx, .95),
                'p99_ns': percentile(fx, .99),
                'worst_ns': max(fx),
            }
            for suffix, value in fx_calculated.items():
                if int(fields[f'gpu_effects_{suffix}']) != value:
                    raise RuntimeError(f'{log_path}: effects {suffix} mismatch')
        else:
            fx_calculated = None
        runs.append({'rep': rep, 'main': calculated, 'effects': fx_calculated,
                     'first_frame': frames[0], 'last_frame': frames[-1]})
        all_main.extend(main)
        all_fx.extend(fx)
    result = {
        'directory': str(directory),
        'samples': len(all_main),
        'main': {k: v for k, v in (
            ('p50_ns', percentile(all_main, .50)),
            ('p95_ns', percentile(all_main, .95)),
            ('p99_ns', percentile(all_main, .99)),
            ('worst_ns', max(all_main)))},
        'runs': runs,
        'capture_sha256': check_ppm(directory / 'rep1.ppm', width, height),
    }
    if effects:
        result['effects'] = {k: v for k, v in (
            ('p50_ns', percentile(all_fx, .50)),
            ('p95_ns', percentile(all_fx, .95)),
            ('p99_ns', percentile(all_fx, .99)),
            ('worst_ns', max(all_fx)))}
    return result

path_rows = []
for width, height, contours in ((256,256,1),(256,256,17),(256,256,31),(256,256,33),(256,256,65),(512,512,1),(512,512,31),(512,512,33),(1024,1024,1),(1024,1024,31),(1024,1024,33)):
    directory = final / 'path' / f'{width}x{height}' / f'c{contours}' / 'candidate'
    item = summarize(directory, False, width, height)
    fields = parse_log(directory / 'rep1.log')
    item.update({key: int(fields[key]) for key in ('contours','curves','bands','selected_band','selected_band_candidates','fractional_roots_at_sample','overflow','covered_pixels')})
    item.update({'width': width, 'height': height, 'lane': 'candidate'})
    path_rows.append(item)

ab_rows = []
for contours in (1,31,33,65):
    for lane in ('control','candidate'):
        directory = final / 'path' / '256x256' / f'c{contours}' / lane
        item = summarize(directory, False, 256, 256)
        item.update({'width': 256, 'height': 256, 'contours': contours, 'lane': lane})
        ab_rows.append(item)

for contours in (1,31,33,65):
    control = next(row for row in ab_rows if row['contours'] == contours and row['lane'] == 'control')
    candidate = next(row for row in ab_rows if row['contours'] == contours and row['lane'] == 'candidate')
    if control['capture_sha256'] != candidate['capture_sha256']:
        raise RuntimeError(f'PPM mismatch at {contours} contours')

glass_rows = []
for material in ('liquid','terminal'):
    for width, height in ((640,480),(1120,760),(1920,1080)):
        directory = final / 'glass' / material / f'{width}x{height}'
        item = summarize(directory, True, width, height)
        fields = parse_log(directory / 'rep1.log')
        item.update({'material': material, 'width': width, 'height': height,
                     'covered_pixels': int(fields['covered_pixels'])})
        glass_rows.append(item)

proof = (final / 'layer-proof' / 'proof.log').read_text()
disabled_layers = (
    'VK_LAYER_VALVE_steam_overlay_32',
    'VK_LAYER_VALVE_steam_overlay_64',
    'VK_LAYER_VALVE_steam_fossilize_32',
    'VK_LAYER_VALVE_steam_fossilize_64',
    'VK_LAYER_MANGOHUD_overlay_x86_64',
    'VK_LAYER_MANGOHUD_overlay_x86',
    'VK_LAYER_NV_optimus',
    'VK_LAYER_NV_present',
    'VK_LAYER_MESA_anti_lag',
    'VK_LAYER_MESA_device_select',
)
for layer in disabled_layers:
    if f'Layer "{layer}" forced disabled' not in proof:
        raise RuntimeError(f'loader proof does not disable {layer}')
if 'VK_LAYER_KHRONOS_validation' in proof:
    raise RuntimeError('loader proof activated or discovered validation layer')
if 'samples=1 gpu_main_samples=1' not in proof or 'raster_valid=1 path_valid=1 close=1' not in proof:
    raise RuntimeError('loader proof benchmark failed')

measurements = {
    'schema': 1,
    'hardware': {'gpu': 'NVIDIA GeForce RTX 3080', 'driver': '610.57.04', 'cpu': 'AMD Ryzen 7 3700X', 'compositor': 'private KWin Wayland goo-nonuat', 'display': '3840x2160 scale 1'},
    'method': {'warmup_frames_per_run': 300, 'measured_frames_per_run': 1000, 'fresh_runs': 3, 'timestamp_stages': ['Main','Effects'], 'validation_layers': 'none', 'loader_filter': 'VK_LOADER_LAYERS_DISABLE=~implicit~', 'implicit_layers_forced_disabled': list(disabled_layers)},
    'supersedes': '/tmp/goo-nonuat-2026-09-05/gpu/measurements.json validation-enabled timing',
    'path_candidate': path_rows,
    'path_ab': ab_rows,
    'glass_final_correctness': glass_rows,
}
(root / 'measurements.json').write_text(json.dumps(measurements, indent=2) + '\n')

comparisons = []
for contours in (1,31,33,65):
    control = next(row for row in ab_rows if row['contours'] == contours and row['lane'] == 'control')
    candidate = next(row for row in ab_rows if row['contours'] == contours and row['lane'] == 'candidate')
    c = control['main']['p50_ns']
    n = candidate['main']['p50_ns']
    comparisons.append({'contours': contours, 'control_p50_ns': c, 'candidate_p50_ns': n,
                        'candidate_change_percent': round((n - c) * 100 / c, 2),
                        'byte_identical_capture': True})

decision = {
    'decision': 'retain',
    'scope': 'Order only fractional roots after the 32-root overflow, then reconstruct distant amount-1 roots from first-pass total parity.',
    'reason': 'The bounded overflow stress cases improve by about 34 percent while captures remain byte-identical. The algorithm remains quadratic in fractional roots.',
    'tradeoff': 'The no-overflow shader carries the measured small-case changes shown in comparisons for 1 and 31 roots.',
    'comparisons': comparisons,
    'swapped_runtime_files': {
        'Vulkan/Shaders/path_band.frag.spv': {'control_sha256': 'ff8ba0f3b071f3d3f62c8b0ee0fb596558f493f4a23e3139d7c1b71a305d4c2c', 'candidate_sha256': 'd35f24052632ec03b9436cb64963d6cd6b6707a4da1a8f3309d45ca35d5ad03f'},
        'Vulkan/Shaders/clip_mask.frag.spv': {'control_sha256': 'f3d6946d46cbb78a9c8c4e098369a0fa4ab69f18cd9f157271578f7898b4208f', 'candidate_sha256': '44d9055153c9bba0822b0eec624473a2468ba30835e6c8d7ec81ed90f3ba8c08'},
        'Vulkan/Shaders/shader-manifest.json': {'control_sha256': 'a51b2705bc7a50f6bab5fab77a9c8e1bcdb237403ead47b9ac5c82958e0a8556', 'candidate_sha256': '37177b52f4d05909ad932a08597b447dd15ebae2b0c6905dc3b378443707d582'},
    },
    'identical_runtime_files': {'Goo.AsyncReadbackSmoke.dll': '127ed8a5ff2bc53b65f51c609578a981c6542d76e1ff84ddd36b05aff5a0e3e8', 'Goo.dll': 'a5782bc002bfb584d0512cfe099626fca6bba0339600fc75baeed5d8412b70d9'},
    'candidate_source_sha256': 'bec23e8fb1ba1e8cf614a27e19a325417da6a7c677472d87725c2d33ffed3d47',
    'control_source_sha256': '4028f811e1ad789b5b26b9d2d34663bd770334b298ba908e5f4c17f667e0bfbc',
    'final_gate': 'Root reports integrated ShaderGen check, vector quality, clip-mask, queue isolation, effect recovery, readback close, and liquid alpha gates passed before this timing run.',
}
for path, lanes in decision['swapped_runtime_files'].items():
    for lane, key in (('control', 'control_sha256'), ('candidate', 'candidate_sha256')):
        if sha256(Path('/tmp/goo-nonuat-2026-09-05/gpu/path-candidate/runtime-ab') / lane / path) != lanes[key]:
            raise RuntimeError(f'runtime hash mismatch: {lane}/{path}')
for name, expected in decision['identical_runtime_files'].items():
    for lane in ('control', 'candidate'):
        if sha256(Path('/tmp/goo-nonuat-2026-09-05/gpu/path-candidate/runtime-ab') / lane / name) != expected:
            raise RuntimeError(f'runtime hash mismatch: {lane}/{name}')
if sha256(root / 'provenance' / 'control-path_band.frag.slang') != decision['control_source_sha256']:
    raise RuntimeError('control source hash mismatch')
if sha256(root / 'provenance' / 'candidate-path_band.frag.slang') != decision['candidate_source_sha256']:
    raise RuntimeError('candidate source hash mismatch')
(root / 'decision.json').write_text(json.dumps(decision, indent=2) + '\n')
print(json.dumps({'validated_path_rows': len(path_rows), 'validated_ab_rows': len(ab_rows), 'validated_glass_rows': len(glass_rows), 'comparisons': comparisons}, indent=2))
